from setuptools import setup, find_packages

package_name = 'lab3_perception'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(),  # will find the nested lab3_perception folder
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='ahmadgill',
    maintainer_email='your_email@example.com',
    description='Lab3 perception package',
    license='Apache License 2.0',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            # Reference the nested package module
            'turtlebot3_circle = lab3_perception.turtlebot3_circle:main',
            'turtlebot3_go2goal = lab3_perception.turtlebot3_go2goal:main',
            'turtlebot3_laserscan = lab3_perception.turtlebot3_laserscan:main',
        ],
    },
)
